import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet
 */
@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
  

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    //     System.out.println("Servlet doget called");
    //     resp.setContentType("text/html");
    //     PrintWriter out = resp.getWriter();
    //     String n=req.getParameter("username");
    //     out.println(n);
    // Cookie ck = new Cookie("username", n);
    // resp.addCookie(ck);
    // out.println("<form action='Servlet1'>");
    // out.print("<input type='submit' value='continue'>");  
    // out.print("</form>");  
    // out.close();
    System.out.println("Servlet doget called");
    resp.setContentType("text/html");  
      PrintWriter out = resp.getWriter();  
    String n=req.getParameter("userName");
  out.print(n);
  
  Cookie ck=new Cookie("userName",n);  
  resp.addCookie(ck);
  
   out.print("<form action='/Servlet1'>");  
      out.print("<input type='submit' value='continue'>");  
      out.print("</form>");  
            
  //out.println("<form action='servlet2.jsp'>");
  //   RequestDispatcher rd=req.getRequestDispatcher("/Servlet2.jsp");
  //   rd.forward(req, resp);
    out.close();
    
    }
}