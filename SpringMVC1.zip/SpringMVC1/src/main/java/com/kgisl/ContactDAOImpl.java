package com.kgisl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
 
/**
 * An implementation of the ContactDAO interface.
 * @author www.codejava.net
 *
 */

public class ContactDAOImpl implements ContactDAO {
 
    private JdbcTemplate jdbcTemplate;
 
    public ContactDAOImpl(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }
 
    @Override
    public void saveOrUpdate(Contact contact) {
        // implementation details goes here...
    }
 
    @Override
    public void delete(int contactId) {
        // implementation details goes here...
    }
 
    @Override
    public List<Contact> list() {
        return null;
        // implementation details goes here...
    }
 
    @Override
    public Contact get(int contactId) {
        return null;
        // implementation details goes here...
    }
 
}
