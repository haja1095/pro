package net.codejava.spring.dao;

import net.codejava.spring.model.Login;
import net.codejava.spring.model.User;
public interface UserDao {
  void register(User user);
  User validateUser(Login login);
}