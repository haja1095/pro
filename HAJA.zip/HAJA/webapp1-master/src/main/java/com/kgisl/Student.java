package com.kgisl;
/**
 * Student
 */
public class Student {
private String stud_Name;
    private int stud_RollNo;
    private String stud_Address;
    private long stud_phone;

    public String getStud_Name() {
        return stud_Name;
    }

    public long getStud_phone() {
		return stud_phone;
	}

	public void setStud_phone(long stud_phone) {
		this.stud_phone = stud_phone;
	}

	public String getStud_Address() {
        return stud_Address;
    }

    public void setStud_Address(String stud_Address) {
        this.stud_Address = stud_Address;
    }

    public int getStud_RollNo() {
        return stud_RollNo;
    }

    public void setStud_RollNo(int stud_RollNo) {
        this.stud_RollNo = stud_RollNo;
    }

    public void setStud_Name(String stud_Name) {
        this.stud_Name = stud_Name;
    }

 
}