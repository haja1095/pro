import java.util.Scanner;

public class fibo{
public static void main(String[] args) {
    int n,a=1,b=4,c=5;
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter value of n:");
    n = s.nextInt();
    System.out.print("Fibonacci Series:");
for(int i = 1; i <= n; i++){
a = b;
b = c;
c = a + b;
System.out.print(a+" ");
}
}    
}