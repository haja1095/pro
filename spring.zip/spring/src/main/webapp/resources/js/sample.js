function doSomeWork() {
	
	alert("wow js is working in spring mvc....");
	
}